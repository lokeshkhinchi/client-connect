import React from 'react'
function NoMatch() {
  return (
    <>404</>
  )
}

export default NoMatch