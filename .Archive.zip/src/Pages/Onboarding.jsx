import React from 'react'
import CafeForm from "../Components/CafeForm"

function Onboarding() {
  return (
    <CafeForm />
  )
}

export default Onboarding